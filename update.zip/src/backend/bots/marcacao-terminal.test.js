jest.mock('puppeteer', () => ({}));
jest.mock('electron', () => ({
    dialog: {
        showMessageBox: jest.fn()
    }
}));

const {
    montarFluxoDinamico,
    resolverTipoUsuarioTerminal,
    exibirDialogContinuacao
} = require('./marcacao-terminal');

describe('resolverTipoUsuarioTerminal', () => {
    test('deve retornar "efetivo" quando o campo nao existir', () => {
        const configPerfil = {
            configuracoes_fixas: {}
        };

        expect(resolverTipoUsuarioTerminal(configPerfil)).toBe('efetivo');
    });

    test('deve retornar "efetivo" e registrar aviso quando o valor for invalido', () => {
        const registrarAviso = jest.fn();
        const configPerfil = {
            configuracoes_fixas: {
                tipo_usuario_terminal: 'qualquer-coisa'
            }
        };

        expect(resolverTipoUsuarioTerminal(configPerfil, registrarAviso)).toBe('efetivo');
        expect(registrarAviso).toHaveBeenCalledWith(
            '   ⚠️ tipo_usuario_terminal inválido (qualquer-coisa). Assumindo "efetivo".'
        );
    });
});

describe('exibirDialogContinuacao', () => {
    test('deve enviar o tipo de usuario no payload ao abrir o modal de instrucoes', async () => {
        const { dialog } = require('electron');
        dialog.showMessageBox.mockResolvedValue({ response: 0 });

        const send = jest.fn();
        const mainWindow = {
            isMinimized: jest.fn(() => false),
            restore: jest.fn(),
            focus: jest.fn(),
            webContents: { send }
        };

        const resposta = await exibirDialogContinuacao(mainWindow, {
            tipoMensagem: 'erro',
            numLinha: 10,
            idProcesso: 'PROC-123',
            ultimoErro: 'Falha de teste',
            tentativaAtual: 1,
            maxTentativas: 3,
            tipoUsuarioTerminal: 'terceirizado'
        });

        expect(resposta.responseIndex).toBe(0);
        expect(resposta.acao.startsWith('ver_instru')).toBe(true);
        expect(send).toHaveBeenCalledWith('abrir-modal-instrucoes', {
            tipoUsuarioTerminal: 'terceirizado'
        });
    });
});

describe('montarFluxoDinamico', () => {
    const linhaBase = {
        'Data pagamento DARE': '01/02/2026',
        'Valor autorizado': '1234,56',
        'Proc. SEI': '202612345678',
        'END -TERMINAL': '123',
        'SEQ - TERMINAL': '480',
        'Tipo': 'DARE'
    };

    const configBase = {
        mapeamento_colunas: {
            TIPO: 'Tipo',
            DATA_PAGAMENTO: 'Data pagamento DARE',
            VALOR_RESTITUIDO: 'Valor autorizado',
            PROCESSO: 'Proc. SEI',
            END: 'END -TERMINAL',
            SEQ: 'SEQ - TERMINAL'
        },
        configuracoes_fixas: {
            tipo_usuario_terminal: 'efetivo'
        }
    };

    const extrairMenusIniciais = (f1) => f1.filter((passo) => typeof passo === 'string');

    test('deve incluir "MARCA DOCUMENTO" quando tipo_usuario_terminal for "efetivo"', () => {
        const fluxo = montarFluxoDinamico(linhaBase, configBase, 'efetivo');

        expect(extrairMenusIniciais(fluxo.f1)).toEqual([
            'RECEITA',
            'SISTEMA DE ARRECADACAO',
            'CORRECAO DE DOCUMENTOS',
            'MARCA DOCUMENTO'
        ]);
    });

    test('nao deve incluir "MARCA DOCUMENTO" quando tipo_usuario_terminal for "terceirizado"', () => {
        const fluxo = montarFluxoDinamico(linhaBase, configBase, 'terceirizado');

        expect(extrairMenusIniciais(fluxo.f1)).toEqual([
            'RECEITA',
            'SISTEMA DE ARRECADACAO',
            'CORRECAO DE DOCUMENTOS'
        ]);
    });

    test('deve usar "efetivo" como fallback quando o campo nao existir', () => {
        const fluxo = montarFluxoDinamico(linhaBase, {
            ...configBase,
            configuracoes_fixas: {}
        });

        expect(extrairMenusIniciais(fluxo.f1)).toContain('MARCA DOCUMENTO');
    });

    test('deve usar "efetivo" como fallback quando o valor configurado for invalido', () => {
        const fluxo = montarFluxoDinamico(linhaBase, {
            ...configBase,
            configuracoes_fixas: {
                tipo_usuario_terminal: 'invalido'
            }
        });

        expect(extrairMenusIniciais(fluxo.f1)).toContain('MARCA DOCUMENTO');
    });
});
