const { 
    preencherTexto, 
    aguardarContextoDoCampo, 
    selecionarOpcaoPorTexto, 
    injetarValor,
    buscarIdBeneficiario,
    marcarOpcao,
    forcarPreenchimentoBloqueado,
    existeTextoNaPagina,
    submeterFormularioComValidacao
} = require('./puppeteer-utils');

describe('preencherTexto', () => {
    let mockContexto;
    let consoleSpy;

    beforeEach(() => {
        // Mock do objeto page/frame do Puppeteer
        mockContexto = {
            click: jest.fn().mockResolvedValue(undefined),
            type: jest.fn().mockResolvedValue(undefined)
        };
        // Espiona o console.log para verificar se avisos são gerados
        consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    });

    afterEach(() => {
        jest.restoreAllMocks();
    });

    test('deve preencher o texto corretamente quando valor é válido', async () => {
        const nomeCampo = 'testeCampo';
        const valor = 'Valor Teste';
        const seletorEsperado = `input[name="${nomeCampo}"], textarea[name="${nomeCampo}"]`;

        await preencherTexto(mockContexto, nomeCampo, valor);

        // Verifica se clicou 3 vezes para selecionar tudo antes de digitar
        expect(mockContexto.click).toHaveBeenCalledWith(seletorEsperado, { clickCount: 3 });
        // Verifica se digitou o valor correto
        expect(mockContexto.type).toHaveBeenCalledWith(seletorEsperado, 'Valor Teste');
        // Não deve ter logado erro
        expect(consoleSpy).not.toHaveBeenCalled();
    });

    test('não deve interagir com a página se o valor for vazio, nulo ou undefined', async () => {
        await preencherTexto(mockContexto, 'campo', '');
        await preencherTexto(mockContexto, 'campo', null);
        await preencherTexto(mockContexto, 'campo', undefined);

        expect(mockContexto.click).not.toHaveBeenCalled();
        expect(mockContexto.type).not.toHaveBeenCalled();
    });

    test('deve converter valores numéricos para string antes de preencher', async () => {
        await preencherTexto(mockContexto, 'campoNumerico', 12345);
        expect(mockContexto.type).toHaveBeenCalledWith(expect.any(String), '12345');
    });

    test('deve capturar erro e logar aviso se a interação com o Puppeteer falhar', async () => {
        const erroSimulado = new Error('Elemento não visível');
        mockContexto.click.mockRejectedValue(erroSimulado);

        const nomeCampo = 'campoComErro';
        await preencherTexto(mockContexto, nomeCampo, 'valor qualquer');

        expect(consoleSpy).toHaveBeenCalledWith(`Aviso: Não consegui escrever em ${nomeCampo}`);
    });
});

describe('aguardarContextoDoCampo', () => {
    let mockPage;

    beforeEach(() => {
        mockPage = {
            waitForSelector: jest.fn(),
            frames: jest.fn().mockReturnValue([])
        };
    });

    test('deve retornar a página se o seletor for encontrado nela', async () => {
        mockPage.waitForSelector.mockResolvedValue(true);
        const resultado = await aguardarContextoDoCampo(mockPage, 'campoTeste');
        expect(resultado).toBe(mockPage);
    });

    test('deve retornar o frame se o seletor for encontrado em um frame', async () => {
        mockPage.waitForSelector.mockRejectedValue(new Error('Timeout'));
        const mockFrame = { waitForSelector: jest.fn().mockResolvedValue(true) };
        mockPage.frames.mockReturnValue([mockFrame]);

        const resultado = await aguardarContextoDoCampo(mockPage, 'campoTeste');
        expect(resultado).toBe(mockFrame);
    });

    test('deve lançar erro se o campo não for encontrado nem na página nem nos frames', async () => {
        mockPage.waitForSelector.mockRejectedValue(new Error('Timeout'));
        mockPage.frames.mockReturnValue([{ waitForSelector: jest.fn().mockRejectedValue(new Error('Timeout')) }]);

        await expect(aguardarContextoDoCampo(mockPage, 'campoTeste', 100))
            .rejects.toThrow('Campo "campoTeste" não encontrado');
    });
});

describe('selecionarOpcaoPorTexto', () => {
    test('deve chamar evaluate com os argumentos corretos', async () => {
        const mockContexto = { evaluate: jest.fn() };
        await selecionarOpcaoPorTexto(mockContexto, 'meuSelect', 'Minha Opção');
        expect(mockContexto.evaluate).toHaveBeenCalledWith(expect.any(Function), 'meuSelect', 'Minha Opção');
    });
});

describe('injetarValor', () => {
    test('deve chamar evaluate para injetar valores', async () => {
        const mockContexto = { evaluate: jest.fn() };
        await injetarValor(mockContexto, { campo: 'txtCampo' }, { campo: 'Valor' });
        expect(mockContexto.evaluate).toHaveBeenCalled();
    });

    test('deve logar erro e relançar exceção se falhar', async () => {
        const erro = new Error('Falha na injeção');
        const mockContexto = { evaluate: jest.fn().mockRejectedValue(erro) };
        const spyErro = jest.spyOn(console, 'error').mockImplementation(() => {});

        await expect(injetarValor(mockContexto, {}, {})).rejects.toThrow('Falha na injeção');
        expect(spyErro).toHaveBeenCalled();
        spyErro.mockRestore();
    });
});

describe('buscarIdBeneficiario', () => {
    let mockBrowser, mockPage;

    beforeEach(() => {
        mockPage = {
            goto: jest.fn(),
            evaluate: jest.fn(),
            close: jest.fn()
        };
        mockBrowser = { newPage: jest.fn().mockResolvedValue(mockPage) };
    });

    test('deve retornar o ID encontrado', async () => {
        mockPage.evaluate.mockResolvedValue('12345');
        const id = await buscarIdBeneficiario(mockBrowser, 'http://site.com', '11122233344');
        
        expect(mockBrowser.newPage).toHaveBeenCalled();
        expect(mockPage.goto).toHaveBeenCalled();
        expect(id).toBe('12345');
        expect(mockPage.close).toHaveBeenCalled();
    });

    test('deve retornar null e logar erro se ocorrer exceção', async () => {
        mockPage.goto.mockRejectedValue(new Error('Erro de rede'));
        const spyErro = jest.spyOn(console, 'error').mockImplementation(() => {});

        const id = await buscarIdBeneficiario(mockBrowser, 'http://site.com', '111');
        
        expect(id).toBeNull();
        expect(spyErro).toHaveBeenCalled();
        expect(mockPage.close).toHaveBeenCalled();
        spyErro.mockRestore();
    });
});

describe('marcarOpcao', () => {
    let mockFrame, mockElement;

    beforeEach(() => {
        mockElement = { click: jest.fn() };
        mockFrame = {
            $: jest.fn().mockResolvedValue(mockElement),
            $eval: jest.fn()
        };
    });

    test('deve clicar se a opção não estiver marcada', async () => {
        mockFrame.$eval.mockResolvedValue(false); // isChecked = false
        await marcarOpcao(mockFrame, 'radio', 'S');
        expect(mockElement.click).toHaveBeenCalled();
    });

    test('não deve clicar se a opção já estiver marcada', async () => {
        mockFrame.$eval.mockResolvedValue(true); // isChecked = true
        await marcarOpcao(mockFrame, 'radio', 'S');
        expect(mockElement.click).not.toHaveBeenCalled();
    });

    test('deve lançar erro se o elemento não for encontrado', async () => {
        mockFrame.$.mockResolvedValue(null);
        await expect(marcarOpcao(mockFrame, 'radio', 'X')).rejects.toThrow('não encontrada');
    });
});

describe('forcarPreenchimentoBloqueado', () => {
    test('deve chamar evaluate se valor for válido', async () => {
        const mockContexto = { evaluate: jest.fn() };
        await forcarPreenchimentoBloqueado(mockContexto, 'campo', 'valor');
        expect(mockContexto.evaluate).toHaveBeenCalled();
    });

    test('não deve fazer nada se valor for vazio', async () => {
        const mockContexto = { evaluate: jest.fn() };
        await forcarPreenchimentoBloqueado(mockContexto, 'campo', '');
        expect(mockContexto.evaluate).not.toHaveBeenCalled();
    });
});

describe('existeTextoNaPagina', () => {
    test('deve estar exportada', () => {
        expect(typeof existeTextoNaPagina).toBe('function');
    });

    test('deve retornar true quando o texto existir na página principal', async () => {
        const mockPage = {
            evaluate: jest.fn().mockResolvedValue(true),
            frames: jest.fn().mockReturnValue([])
        };

        const resultado = await existeTextoNaPagina(mockPage, 'Texto alvo');

        expect(resultado).toBe(true);
        expect(mockPage.evaluate).toHaveBeenCalledWith(expect.any(Function), 'Texto alvo');
        expect(mockPage.frames).not.toHaveBeenCalled();
    });

    test('deve retornar true quando o texto existir em um frame', async () => {
        const mockFrame = { evaluate: jest.fn().mockResolvedValue(true) };
        const mockPage = {
            evaluate: jest.fn().mockResolvedValue(false),
            frames: jest.fn().mockReturnValue([mockFrame])
        };

        const resultado = await existeTextoNaPagina(mockPage, 'Texto no frame');

        expect(resultado).toBe(true);
        expect(mockPage.evaluate).toHaveBeenCalledWith(expect.any(Function), 'Texto no frame');
        expect(mockFrame.evaluate).toHaveBeenCalledWith(expect.any(Function), 'Texto no frame');
    });

    test('deve retornar false quando o texto não existir na página nem nos frames', async () => {
        const mockFrame = { evaluate: jest.fn().mockResolvedValue(false) };
        const mockPage = {
            evaluate: jest.fn().mockResolvedValue(false),
            frames: jest.fn().mockReturnValue([mockFrame])
        };

        const resultado = await existeTextoNaPagina(mockPage, 'Inexistente');

        expect(resultado).toBe(false);
    });

    test('deve retornar false quando o texto alvo for vazio', async () => {
        const mockPage = {
            evaluate: jest.fn(),
            frames: jest.fn()
        };

        await expect(existeTextoNaPagina(mockPage, '')).resolves.toBe(false);
        await expect(existeTextoNaPagina(mockPage, '   ')).resolves.toBe(false);
        await expect(existeTextoNaPagina(mockPage, null)).resolves.toBe(false);

        expect(mockPage.evaluate).not.toHaveBeenCalled();
        expect(mockPage.frames).not.toHaveBeenCalled();
    });

    test('deve ignorar falha em frame isolado e continuar a busca', async () => {
        const frameComErro = { evaluate: jest.fn().mockRejectedValue(new Error('Frame inacessível')) };
        const frameComTexto = { evaluate: jest.fn().mockResolvedValue(true) };
        const mockPage = {
            evaluate: jest.fn().mockResolvedValue(false),
            frames: jest.fn().mockReturnValue([frameComErro, frameComTexto])
        };

        const resultado = await existeTextoNaPagina(mockPage, 'Texto resiliente');

        expect(resultado).toBe(true);
        expect(frameComErro.evaluate).toHaveBeenCalledWith(expect.any(Function), 'Texto resiliente');
        expect(frameComTexto.evaluate).toHaveBeenCalledWith(expect.any(Function), 'Texto resiliente');
    });
});

describe('submeterFormularioComValidacao', () => {
    let mockPage, mockContexto, mockDialog;

    beforeEach(() => {
        mockDialog = {
            message: jest.fn().mockReturnValue('Mensagem de sucesso'),
            accept: jest.fn().mockResolvedValue(undefined)
        };
        mockPage = {
            once: jest.fn((event, callback) => {
                if (event === 'dialog') {
                    callback(mockDialog);
                }
            })
        };
        mockContexto = {
            evaluate: jest.fn().mockResolvedValue(undefined),
            click: jest.fn().mockResolvedValue(undefined)
        };
    });

    test('deve resolver com a mensagem do dialog quando o dialog é disparado', async () => {
        const resultado = await submeterFormularioComValidacao(mockPage, mockContexto, 'button[name="submit"]');

        expect(resultado).toBe('Mensagem de sucesso');
        expect(mockPage.once).toHaveBeenCalledWith('dialog', expect.any(Function));
        expect(mockDialog.accept).toHaveBeenCalled();
    });

    test('deve chamar contexto.evaluate para injetar código de bypass', async () => {
        await submeterFormularioComValidacao(mockPage, mockContexto, 'button[name="submit"]');

        expect(mockContexto.evaluate).toHaveBeenCalledWith(expect.any(Function));
    });

    test('deve chamar contexto.click com o seletor correto', async () => {
        const seletor = 'button[name="submit"]';
        await submeterFormularioComValidacao(mockPage, mockContexto, seletor);

        expect(mockContexto.click).toHaveBeenCalledWith(seletor);
    });

    test('deve rejeitar com erro de timeout se o dialog não for disparado dentro do timeout', async () => {
        // Mock page.once para não chamar o callback
        mockPage.once = jest.fn();

        await expect(submeterFormularioComValidacao(mockPage, mockContexto, 'button[name="submit"]', 100))
            .rejects.toThrow('Tempo esgotado aguardando resposta do servidor (Alert).');
    });

    test('deve usar o timeout padrão se não especificado', async () => {
        // Para este teste, apenas verificar que não lança erro imediatamente
        // Como mockamos o dialog, ele resolve
        const resultado = await submeterFormularioComValidacao(mockPage, mockContexto, 'button[name="submit"]');
        expect(resultado).toBe('Mensagem de sucesso');
    });
});
