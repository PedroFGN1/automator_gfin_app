/**
 * @file updater.js
 * @description Gerencia a atualização automática via GitHub (Versionamento e Download)
 */

const https = require('https');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// CONFIGURAÇÃO: Substitua pelos seus links RAW do GitHub
const URL_VERSION_RAW = 'https://raw.githubusercontent.com/PedroFGN1/automator_gfin_app/refs/heads/main/version.json';
const URL_ZIP_RELEASE = 'https://raw.githubusercontent.com/PedroFGN1/automator_gfin_app/refs/heads/main/update.zip';

const CAMINHO_LOCAL_VERSAO = path.join(__dirname, '../../../version.json');
const PASTA_RAIZ = path.join(__dirname, '../../../');
const ARQUIVO_TEMP_ZIP = path.join(PASTA_RAIZ, 'update_temp.zip');

async function checkAndUpdate() {
    try {
        console.log("--- Verificando atualizações no GitHub ---");

        // 1. LER VERSÃO REMOTA
        const remoteData = await downloadText(URL_VERSION_RAW);
        const remoteJSON = JSON.parse(remoteData);
        
        // 2. LER VERSÃO LOCAL
        const localJSON = JSON.parse(fs.readFileSync(CAMINHO_LOCAL_VERSAO, 'utf8'));

        if (remoteJSON.version !== localJSON.version) {
            console.log(`Nova versão detectada: ${remoteJSON.version}. Baixando...`);

            // 3. BAIXAR O ZIP
            await downloadFile(URL_ZIP_RELEASE, ARQUIVO_TEMP_ZIP);

            // 4. DESCOMPACTAR USANDO POWERSHELL (Nativo do Windows)
            console.log("Preparando arquivos para substituição...");
            const pastaUpdate = path.join(PASTA_RAIZ, 'update_files');
            
            // Cria a pasta se não existir
            if (!fs.existsSync(pastaUpdate)) fs.mkdirSync(pastaUpdate);

            const psCommand = `powershell -command "Expand-Archive -Path '${ARQUIVO_TEMP_ZIP}' -DestinationPath '${pastaUpdate}' -Force"`;
            execSync(psCommand);

            // 5. LIMPEZA DO ZIP
            fs.unlinkSync(ARQUIVO_TEMP_ZIP);
            console.log("✅ Arquivos prontos. O sistema sera reiniciado para aplicar.");
        } else {
            console.log("✅ O sistema já está na versão mais recente.");
        }
    } catch (err) {
        console.error("❌ Falha na atualização automática:", err.message);
        console.log("Iniciando o robô com a versão atual...");
    }
}

// Funções Auxiliares (Promisified para facilitar o uso do await)
function downloadText(url) {
    return new Promise((resolve, reject) => {
        https.get(url, (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => resolve(data));
        }).on('error', reject);
    });
}

function downloadFile(url, dest) {
    return new Promise((resolve, reject) => {
        const file = fs.createWriteStream(dest);
        https.get(url, (res) => {
            res.pipe(file);
            file.on('finish', () => {
                file.close();
                resolve();
            });
        }).on('error', (err) => {
            fs.unlink(dest, () => {}); 
            reject(err);
        });
    });
}

checkAndUpdate();