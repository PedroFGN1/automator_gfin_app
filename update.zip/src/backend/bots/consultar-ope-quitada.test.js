jest.mock("puppeteer", () => ({
    launch: jest.fn()
}));

jest.mock("fs", () => ({
    writeFileSync: jest.fn()
}));

jest.mock("electron", () => ({
    dialog: {
        showMessageBox: jest.fn()
    }
}));

jest.mock("../utils/file-utils", () => ({
    prepararDiretorios: jest.fn(),
    lerExcelInput: jest.fn(),
    exportarRelatorios: jest.fn()
}));

jest.mock("../utils/puppeteer-utils", () => ({
    aguardarContextoDoCampo: jest.fn(),
    preencherTexto: jest.fn()
}));

jest.mock("../utils/navigation-utils", () => ({
    delay: jest.fn()
}));

jest.mock("../utils/logger", () => ({
    gravarLogSistema: jest.fn()
}));

const path = require("path");
const fs = require("fs");
const puppeteer = require("puppeteer");
const fileUtils = require("../utils/file-utils");
const pptUtils = require("../utils/puppeteer-utils");
const navUtils = require("../utils/navigation-utils");
const logger = require("../utils/logger");
const { dialog } = require("electron");
const { executarConsultaOPEQuitada } = require("./consultar-ope-quitada");

describe("executarConsultaOPEQuitada", () => {
    const configPerfil = {
        nome: "Consulta OPE Quitada",
        url_portal: "https://portal.exemplo/login",
        url_formulario_direto: "https://portal.exemplo/consultar-op",
        configuracoes_fixas: {
            names: {
                campo_orgao: "orgao",
                campo_sequencial_op: "sequencialOP",
                botao_dueof: "Dueof"
            },
            orgao_codigo: "9995"
        },
        mapeamento_colunas: {
            OP: "OP"
        }
    };

    const diretoriosMock = {
        base: "C:/saida/Consulta OPE Quitada/2026-03-31",
        planilhas: "C:/saida/Consulta OPE Quitada/2026-03-31/Planilhas",
        evidencias: "C:/saida/Consulta OPE Quitada/2026-03-31/Evidencias/10-00-00"
    };

    let enviarLog;
    let controle;
    let browser;
    let page;
    let contexto;
    let btnConsultar;
    let btnDueof;

    beforeEach(() => {
        jest.clearAllMocks();

        enviarLog = jest.fn();
        controle = { abortar: false };

        btnConsultar = {
            click: jest.fn().mockResolvedValue(undefined)
        };

        btnDueof = {
            id: "btnDueof"
        };

        contexto = {
            $: jest.fn(async (selector) => {
                if (selector === 'input[value="Consultar"]') return btnConsultar;
                if (selector === 'input[value="Dueof"]') return btnDueof;
                return null;
            }),
            evaluate: jest.fn(async (_fn, arg) => {
                if (arg === btnDueof) {
                    return "window.location='/download?arquivo=dueof&amp;tipo=pdf'";
                }
                if (arg === "/download?arquivo=dueof&tipo=pdf") {
                    return Buffer.from("pdf-mock").toString("base64");
                }
                return null;
            })
        };

        page = {
            goto: jest.fn().mockResolvedValue(undefined),
            waitForNavigation: jest.fn().mockResolvedValue(undefined),
            screenshot: jest.fn().mockResolvedValue(undefined)
        };

        browser = {
            pages: jest.fn().mockResolvedValue([page]),
            newPage: jest.fn().mockResolvedValue(page),
            close: jest.fn().mockResolvedValue(undefined)
        };

        puppeteer.launch.mockResolvedValue(browser);
        dialog.showMessageBox.mockResolvedValue({ response: 0 });
        fileUtils.prepararDiretorios.mockReturnValue(diretoriosMock);
        fileUtils.lerExcelInput.mockResolvedValue([{ OP: "2026.9995.2867" }]);
        fileUtils.exportarRelatorios.mockImplementation(async (_dir, resultados) => ({
            qtdSucesso: resultados.filter((item) => item.status === "SUCESSO").length,
            qtdErro: resultados.filter((item) => item.status === "ERRO").length
        }));
        pptUtils.aguardarContextoDoCampo.mockResolvedValue(contexto);
        pptUtils.preencherTexto.mockResolvedValue(undefined);
        navUtils.delay.mockResolvedValue(undefined);
    });

    it("deve processar uma OP quitada, baixar o Dueof e exportar o relatório final", async () => {
        // Valida o fluxo de negócio completo: login, consulta da OP quitada, download do comprovante e consolidação do relatório.
        const resultado = await executarConsultaOPEQuitada(
            configPerfil,
            "C:/entrada/ops.xlsx",
            "C:/saida",
            enviarLog,
            controle
        );

        expect(resultado).toEqual({
            sucesso: true,
            resumo: { qtdSucesso: 1, qtdErro: 0 }
        });
        expect(page.goto).toHaveBeenNthCalledWith(1, configPerfil.url_portal, { waitUntil: "domcontentloaded" });
        expect(page.goto).toHaveBeenNthCalledWith(2, configPerfil.url_formulario_direto, { waitUntil: "domcontentloaded" });
        expect(dialog.showMessageBox).toHaveBeenCalledTimes(1);
        expect(pptUtils.aguardarContextoDoCampo).toHaveBeenNthCalledWith(1, page, "orgao");
        expect(pptUtils.preencherTexto).toHaveBeenNthCalledWith(1, contexto, "orgao", "9995");
        expect(pptUtils.preencherTexto).toHaveBeenNthCalledWith(2, contexto, "sequencialOP", "2867");
        expect(contexto.$).toHaveBeenCalledWith('input[value="Consultar"]');
        expect(page.waitForNavigation).toHaveBeenCalledWith({ waitUntil: "domcontentloaded" });
        expect(btnConsultar.click).toHaveBeenCalledTimes(1);
        expect(pptUtils.aguardarContextoDoCampo).toHaveBeenNthCalledWith(2, page, "Dueof");
        expect(contexto.$).toHaveBeenCalledWith('input[value="Dueof"]');
        expect(contexto.evaluate).toHaveBeenNthCalledWith(1, expect.any(Function), btnDueof);
        expect(contexto.evaluate).toHaveBeenNthCalledWith(2, expect.any(Function), "/download?arquivo=dueof&tipo=pdf");
        expect(fs.writeFileSync).toHaveBeenCalledWith(
            path.join(diretoriosMock.evidencias, "2026.9995.2867.pdf"),
            expect.any(Buffer)
        );
        expect(fileUtils.exportarRelatorios).toHaveBeenCalledWith(diretoriosMock.planilhas, [
            expect.objectContaining({
                status: "SUCESSO",
                linha: 1,
                mensagem: "PDF Dueof baixado com sucesso.",
                numeroOP: "2026.9995.2867"
            })
        ]);
        expect(browser.close).toHaveBeenCalledTimes(1);
    });

    it("deve preencher apenas o sequencial final da OP ao realizar a consulta", async () => {
        // Garante a regra funcional de extrair só o último segmento da OP para o campo sequencial, como no fluxo real do usuário.
        fileUtils.lerExcelInput.mockResolvedValue([{ OP: "2026.1234.9876" }]);

        await executarConsultaOPEQuitada(
            configPerfil,
            "C:/entrada/ops.xlsx",
            "C:/saida",
            enviarLog,
            controle
        );

        expect(pptUtils.preencherTexto).toHaveBeenNthCalledWith(2, contexto, "sequencialOP", "9876");
        expect(pptUtils.preencherTexto).not.toHaveBeenCalledWith(contexto, "sequencialOP", "2026.1234.9876");
    });

    it("deve retornar erro fatal quando o usuário cancelar durante a etapa de login", async () => {
        // Valida o handshake manual do portal: se o usuário cancelar, o bot encerra com falha geral e ainda fecha o navegador.
        dialog.showMessageBox.mockResolvedValue({ response: 1 });

        const resultado = await executarConsultaOPEQuitada(
            configPerfil,
            "C:/entrada/ops.xlsx",
            "C:/saida",
            enviarLog,
            controle
        );

        expect(resultado).toEqual({
            sucesso: false,
            erro: "Operação cancelada pelo usuário durante o login."
        });
        expect(fileUtils.exportarRelatorios).not.toHaveBeenCalled();
        expect(browser.close).toHaveBeenCalledTimes(1);
    });

    it("deve registrar erro por linha quando a planilha não trouxer o número da OP", async () => {
        // Confirma que uma linha inválida da planilha não derruba o lote inteiro e gera evidência de erro para revisão.
        fileUtils.lerExcelInput.mockResolvedValue([{}]);

        const resultado = await executarConsultaOPEQuitada(
            configPerfil,
            "C:/entrada/ops.xlsx",
            "C:/saida",
            enviarLog,
            controle
        );

        expect(resultado).toEqual({
            sucesso: true,
            resumo: { qtdSucesso: 0, qtdErro: 1 }
        });
        expect(page.screenshot).toHaveBeenCalledWith({
            path: path.join(diretoriosMock.evidencias, "ERRO_LINHA_1.png"),
            fullPage: true
        });
        expect(fileUtils.exportarRelatorios).toHaveBeenCalledWith(diretoriosMock.planilhas, [
            expect.objectContaining({
                status: "ERRO",
                linha: 1,
                mensagem: "Número da OP não encontrado na planilha.",
                numeroOP: ""
            })
        ]);
    });

    it("deve registrar erro por linha quando o botão Consultar não estiver disponível", async () => {
        // Garante que falhas na tela de consulta sejam capturadas como erro operacional da linha, sem interromper o relatório.
        contexto.$.mockImplementation(async (selector) => {
            if (selector === 'input[value="Consultar"]') return null;
            if (selector === 'input[value="Dueof"]') return btnDueof;
            return null;
        });

        const resultado = await executarConsultaOPEQuitada(
            configPerfil,
            "C:/entrada/ops.xlsx",
            "C:/saida",
            enviarLog,
            controle
        );

        expect(resultado).toEqual({
            sucesso: true,
            resumo: { qtdSucesso: 0, qtdErro: 1 }
        });
        expect(fileUtils.exportarRelatorios).toHaveBeenCalledWith(diretoriosMock.planilhas, [
            expect.objectContaining({
                status: "ERRO",
                mensagem: "Botão 'Consultar' não encontrado na tela."
            })
        ]);
        expect(page.screenshot).toHaveBeenCalledTimes(1);
    });

    it("deve registrar erro por linha quando a OP consultada não tiver botão Dueof", async () => {
        // Representa a consulta de uma OP não quitada: a navegação funciona, mas o comprovante não fica disponível para download.
        contexto.$.mockImplementation(async (selector) => {
            if (selector === 'input[value="Consultar"]') return btnConsultar;
            if (selector === 'input[value="Dueof"]') return null;
            return null;
        });

        const resultado = await executarConsultaOPEQuitada(
            configPerfil,
            "C:/entrada/ops.xlsx",
            "C:/saida",
            enviarLog,
            controle
        );

        expect(resultado).toEqual({
            sucesso: true,
            resumo: { qtdSucesso: 0, qtdErro: 1 }
        });
        expect(fileUtils.exportarRelatorios).toHaveBeenCalledWith(diretoriosMock.planilhas, [
            expect.objectContaining({
                status: "ERRO",
                mensagem: "Botão 'Dueof' não encontrado. Verifique se a OP está quitada."
            })
        ]);
    });

    it("deve registrar erro por linha quando não conseguir extrair a URL de download do Dueof", async () => {
        // Valida a etapa crítica de leitura do onclick do botão, usada para baixar o PDF mantendo a sessão autenticada.
        contexto.evaluate.mockImplementation(async (_fn, arg) => {
            if (arg === btnDueof) {
                return "abrirPopupSemUrlValida()";
            }
            if (typeof arg === "string") {
                return Buffer.from("pdf-mock").toString("base64");
            }
            return null;
        });

        const resultado = await executarConsultaOPEQuitada(
            configPerfil,
            "C:/entrada/ops.xlsx",
            "C:/saida",
            enviarLog,
            controle
        );

        expect(resultado).toEqual({
            sucesso: true,
            resumo: { qtdSucesso: 0, qtdErro: 1 }
        });
        expect(fs.writeFileSync).not.toHaveBeenCalled();
        expect(fileUtils.exportarRelatorios).toHaveBeenCalledWith(diretoriosMock.planilhas, [
            expect.objectContaining({
                status: "ERRO",
                mensagem: "Não foi possível extrair a URL de download do botão Dueof."
            })
        ]);
    });

    it("deve registrar erro por linha quando o download do PDF falhar com erro HTTP e continuar o lote", async () => {
        // Garante resiliência por linha: uma falha 500 no fetch interno do PDF vira erro da linha, mas a próxima OP ainda é processada.
        fileUtils.lerExcelInput.mockResolvedValue([
            { OP: "2026.9995.2867" },
            { OP: "2026.9995.2868" }
        ]);

        let opAtual = null;
        pptUtils.preencherTexto.mockImplementation(async (_contexto, nomeCampo, valor) => {
            if (nomeCampo === "sequencialOP") {
                opAtual = valor;
            }
        });

        contexto.evaluate.mockImplementation(async (_fn, arg) => {
            if (arg === btnDueof) {
                return "window.location='/download?arquivo=dueof&amp;tipo=pdf'";
            }

            if (arg === "/download?arquivo=dueof&tipo=pdf") {
                if (opAtual === "2867") {
                    throw new Error("Erro HTTP no download: 500");
                }

                return Buffer.from(`pdf-mock-${opAtual}`).toString("base64");
            }

            return null;
        });

        const resultado = await executarConsultaOPEQuitada(
            configPerfil,
            "C:/entrada/ops.xlsx",
            "C:/saida",
            enviarLog,
            controle
        );

        expect(resultado).toEqual({
            sucesso: true,
            resumo: { qtdSucesso: 1, qtdErro: 1 }
        });
        expect(page.screenshot).toHaveBeenCalledWith({
            path: path.join(diretoriosMock.evidencias, "ERRO_LINHA_1.png"),
            fullPage: true
        });
        expect(fs.writeFileSync).toHaveBeenCalledTimes(1);
        expect(fs.writeFileSync).toHaveBeenCalledWith(
            path.join(diretoriosMock.evidencias, "2026.9995.2868.pdf"),
            expect.any(Buffer)
        );
        expect(fileUtils.exportarRelatorios).toHaveBeenCalledWith(diretoriosMock.planilhas, [
            expect.objectContaining({
                status: "ERRO",
                linha: 1,
                mensagem: "Erro HTTP no download: 500",
                numeroOP: "2026.9995.2867"
            }),
            expect.objectContaining({
                status: "SUCESSO",
                linha: 2,
                mensagem: "PDF Dueof baixado com sucesso.",
                numeroOP: "2026.9995.2868"
            })
        ]);
    });

    it("deve interromper o loop quando o controle de abortar estiver ativo", async () => {
        // Garante que o usuário consiga parar o processamento antes das consultas e ainda obter o fechamento do lote.
        controle.abortar = true;

        const resultado = await executarConsultaOPEQuitada(
            configPerfil,
            "C:/entrada/ops.xlsx",
            "C:/saida",
            enviarLog,
            controle
        );

        expect(resultado).toEqual({
            sucesso: true,
            resumo: { qtdSucesso: 0, qtdErro: 0 }
        });
        expect(page.goto).toHaveBeenCalledTimes(1);
        expect(pptUtils.preencherTexto).not.toHaveBeenCalled();
        expect(fileUtils.exportarRelatorios).toHaveBeenCalledWith(diretoriosMock.planilhas, []);
    });

    it("deve fechar o navegador mesmo quando ocorrer erro fatal antes do processamento das linhas", async () => {
        // Protege o cleanup do navegador quando a preparação do lote falha antes de entrar no loop principal.
        fileUtils.lerExcelInput.mockRejectedValue(new Error("Falha ao ler Excel"));

        const resultado = await executarConsultaOPEQuitada(
            configPerfil,
            "C:/entrada/ops.xlsx",
            "C:/saida",
            enviarLog,
            controle
        );

        expect(resultado).toEqual({
            sucesso: false,
            erro: "Falha ao ler Excel"
        });
        expect(browser.close).not.toHaveBeenCalled();
    });

    it("deve fechar o navegador no finally quando ocorrer erro fatal após a abertura do browser", async () => {
        // Confirma que falhas depois do launch não deixam instâncias do navegador abertas.
        page.goto.mockRejectedValueOnce(new Error("Portal indisponível"));

        const resultado = await executarConsultaOPEQuitada(
            configPerfil,
            "C:/entrada/ops.xlsx",
            "C:/saida",
            enviarLog,
            controle
        );

        expect(resultado).toEqual({
            sucesso: false,
            erro: "Portal indisponível"
        });
        expect(browser.close).toHaveBeenCalledTimes(1);
    });
});
